# animutyam (VIPT B.Pharm Exam & Live Attendance Portal)

A mindful, student-friendly academic companion featuring real-time college portal attendance sync, safe bunks calculation, target projections (75%, 85%, 90%, 95%), subject-wise progress graphs, and community goals.

## 🚀 How to Deploy to Vercel (100% Free, 24/7 Online)

### Step 1: Upload to GitHub
1. Open [github.com](https://github.com) and sign in (or create a free account).
2. Click **New Repository** (Name: `animutyam`, Public or Private).
3. Click the link that says **"uploading an existing file"**.
4. Drag and drop all files from this folder (`index.html`, `package.json`, `vercel.json`, `api/`, `assets/`) and click **Commit changes**.

### Step 2: Deploy on Vercel
1. Open [vercel.com](https://vercel.com) and click **"Continue with GitHub"**.
2. Click **"Add New..."** > **"Project"**.
3. Select your `animutyam` repository from the list.
4. Leave all settings at default and click **Deploy**.
5. In ~30 seconds, your site is live at a URL like `https://animutyam.vercel.app`!

---

## 💻 Running Locally
Double-click `run-website.bat` to launch the local server at `http://localhost:8080/`.
