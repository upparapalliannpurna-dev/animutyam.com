@echo off
setlocal
cd /d "%~dp0"
set PATH=C:\Users\Nani\AppData\Local\Programs\Git\cmd;%PATH%

echo ========================================================
echo        animutyam - Push Project to GitHub
echo ========================================================
echo.
echo Make sure you created an empty repository on GitHub first!
echo (e.g. https://github.com/YOUR_USERNAME/animutyam)
echo.
set /p REPO_URL="Enter your GitHub Repository URL: "

if "%REPO_URL%"=="" (
    echo [ERROR] No URL provided. Exiting...
    pause
    exit /b 1
)

echo.
echo Setting remote origin to %REPO_URL% ...
git remote remove origin 2>nul
git remote add origin %REPO_URL%
git branch -M main

echo.
echo Pushing code to GitHub...
git push -u origin main

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo  SUCCESS! Your code is now live on GitHub!
    echo  You can now go to https://vercel.com to deploy it!
    echo ========================================================
) else (
    echo.
    echo [NOTE] If you were prompted for login, complete the GitHub sign-in prompt.
)

pause
