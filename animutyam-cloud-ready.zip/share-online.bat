@echo off
setlocal
cd /d "%~dp0"

echo ================================================================
echo       animutyam - Launch Public Website via Cloudflare
echo ================================================================
echo.

:: Check if local server is already running on port 8080
netstat -ano | findstr ":8080" | findstr "LISTENING" >nul
if %ERRORLEVEL% NEQ 0 (
    echo [1/2] Starting local animutyam server...
    start /min powershell -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
    timeout /t 2 /nobreak >nul
) else (
    echo [1/2] Local server is already running on port 8080.
)

echo [2/2] Connecting to Cloudflare global network...
echo.
echo ================================================================
echo  LOOK BELOW for the line starting with:
echo  https://...trycloudflare.com
echo.
echo  Share that https:// link with your classmates or open it
echo  on your mobile phone!
echo ================================================================
echo.

"%~dp0cloudflared.exe" tunnel --url http://localhost:8080 --http-host-header localhost

pause
