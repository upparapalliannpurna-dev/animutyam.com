@echo off
title animutyam Web Server
echo ==============================================
echo   Launching animutyam Website...
echo ==============================================
echo.
start "" "http://localhost:8080/"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
pause
